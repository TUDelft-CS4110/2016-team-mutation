/**
  * This package contains classes to control the game,
  * such as timers for moving ghosts around.
  * 
  * @author Arie van Deursen, January 2012.
  */
package org.jpacman.framework.controller;
